import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Flex, 
  VStack, 
  HStack,
  Heading, 
  Text, 
  Button, 
  Badge,
  Progress,
  Grid,
  GridItem,
  Card,
  CardBody,
  CardHeader,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  useColorModeValue,
  Tooltip,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Spinner,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription
} from '@chakra-ui/react';
import { FiPlay, FiPause, FiRefreshCw, FiEye, FiUsers, FiActivity, FiZap } from 'react-icons/fi';

interface Agent {
  id: string;
  name: string;
  district: string;
  role: string;
  experience_level: string;
  status: 'idle' | 'working' | 'completed' | 'failed' | 'waiting';
  current_task?: string;
  dependencies: string[];
}

interface District {
  name: string;
  wave: number;
  status: string;
  agents: Agent[];
  is_complete: boolean;
}

interface CityStatus {
  project_id: string;
  status: string;
  current_wave: number;
  total_agents: number;
  active_agents: number;
  completed_agents: number;
  progress_percentage: number;
  districts: { [key: string]: any };
}

interface AgentCityProps {
  onDeployCity: (requirements: string) => void;
  isDeploying: boolean;
}

const AgentCity: React.FC<AgentCityProps> = ({ onDeployCity, isDeploying }) => {
  const [cityStatus, setCityStatus] = useState<CityStatus | null>(null);
  const [selectedDistrict, setSelectedDistrict] = useState<District | null>(null);
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [requirements, setRequirements] = useState('');
  
  const { isOpen: isDistrictOpen, onOpen: onDistrictOpen, onClose: onDistrictClose } = useDisclosure();
  const { isOpen: isAgentOpen, onOpen: onAgentOpen, onClose: onAgentClose } = useDisclosure();
  
  const bgColor = useColorModeValue('gray.50', 'gray.900');
  const cardBg = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  // Fetch city status
  const fetchCityStatus = async () => {
    try {
      const response = await fetch('/api/agent-city/status');
      const data = await response.json();
      setCityStatus(data);
    } catch (error) {
      console.error('Failed to fetch city status:', error);
    }
  };

  // Fetch district details
  const fetchDistrictDetails = async (districtName: string) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/agent-city/district/${districtName}`);
      const data = await response.json();
      setSelectedDistrict(data);
      onDistrictOpen();
    } catch (error) {
      console.error('Failed to fetch district details:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch agent details
  const fetchAgentDetails = async (agentId: string) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/agent-city/agent/${agentId}`);
      const data = await response.json();
      setSelectedAgent(data);
      onAgentOpen();
    } catch (error) {
      console.error('Failed to fetch agent details:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch logs
  const fetchLogs = async () => {
    try {
      const response = await fetch('/api/agent-city/logs?limit=20');
      const data = await response.json();
      setLogs(data);
    } catch (error) {
      console.error('Failed to fetch logs:', error);
    }
  };

  // Deploy city
  const handleDeployCity = async () => {
    if (!requirements.trim()) return;
    
    try {
      const response = await fetch('/api/agent-city/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          requirements,
          user_id: 'demo_user' // In real app, this would come from auth
        })
      });
      
      const data = await response.json();
      if (data.success) {
        onDeployCity(requirements);
        fetchCityStatus();
        fetchLogs();
      }
    } catch (error) {
      console.error('Failed to deploy city:', error);
    }
  };

  // Advance wave
  const handleAdvanceWave = async () => {
    try {
      const response = await fetch('/api/agent-city/advance-wave', {
        method: 'POST'
      });
      const data = await response.json();
      if (data.success) {
        fetchCityStatus();
        fetchLogs();
      }
    } catch (error) {
      console.error('Failed to advance wave:', error);
    }
  };

  // Reset city
  const handleResetCity = async () => {
    try {
      const response = await fetch('/api/agent-city/reset', {
        method: 'POST'
      });
      const data = await response.json();
      if (data.success) {
        setCityStatus(null);
        setLogs([]);
      }
    } catch (error) {
      console.error('Failed to reset city:', error);
    }
  };

  // Auto-refresh status
  useEffect(() => {
    const interval = setInterval(() => {
      if (cityStatus && cityStatus.status === 'active') {
        fetchCityStatus();
        fetchLogs();
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [cityStatus]);

  // Initial load
  useEffect(() => {
    fetchCityStatus();
    fetchLogs();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'working': return 'blue';
      case 'completed': return 'green';
      case 'failed': return 'red';
      case 'waiting': return 'yellow';
      default: return 'gray';
    }
  };

  const getDistrictColor = (districtName: string) => {
    const colors: { [key: string]: string } = {
      'planning': 'blue',
      'foundation': 'orange',
      'component': 'green',
      'logic': 'purple',
      'design': 'pink',
      'animation': 'cyan',
      'performance': 'red',
      'quality': 'teal',
      'deployment': 'yellow'
    };
    return colors[districtName] || 'gray';
  };

  return (
    <Box p={6} bg={bgColor} minH="100vh">
      {/* Header */}
      <VStack spacing={6} align="stretch">
        <Flex justify="space-between" align="center">
          <VStack align="start" spacing={2}>
            <Heading size="lg" color="teal.500">
              <FiZap style={{ display: 'inline', marginRight: '8px' }} />
              Agent City
            </Heading>
            <Text color="gray.600">
              30 specialized AI agents working together to build your application
            </Text>
          </VStack>
          
          <HStack spacing={3}>
            <Button
              leftIcon={<FiRefreshCw />}
              onClick={fetchCityStatus}
              size="sm"
              variant="outline"
            >
              Refresh
            </Button>
            <Button
              leftIcon={<FiPause />}
              onClick={handleResetCity}
              size="sm"
              colorScheme="red"
              variant="outline"
            >
              Reset City
            </Button>
          </HStack>
        </Flex>

        {/* City Overview Stats */}
        {cityStatus && (
          <Grid templateColumns="repeat(auto-fit, minmax(200px, 1fr))" gap={4}>
            <Card bg={cardBg}>
              <CardBody>
                <Stat>
                  <StatLabel>Project Status</StatLabel>
                  <StatNumber>
                    <Badge colorScheme={cityStatus.status === 'active' ? 'green' : 'gray'}>
                      {cityStatus.status.toUpperCase()}
                    </Badge>
                  </StatNumber>
                  <StatHelpText>Current Wave: {cityStatus.current_wave}/9</StatHelpText>
                </Stat>
              </CardBody>
            </Card>

            <Card bg={cardBg}>
              <CardBody>
                <Stat>
                  <StatLabel>Progress</StatLabel>
                  <StatNumber>{Math.round(cityStatus.progress_percentage)}%</StatNumber>
                  <Progress 
                    value={cityStatus.progress_percentage} 
                    colorScheme="teal" 
                    size="sm" 
                    mt={2}
                  />
                </Stat>
              </CardBody>
            </Card>

            <Card bg={cardBg}>
              <CardBody>
                <Stat>
                  <StatLabel>Active Agents</StatLabel>
                  <StatNumber color="blue.500">{cityStatus.active_agents}</StatNumber>
                  <StatHelpText>of {cityStatus.total_agents} total</StatHelpText>
                </Stat>
              </CardBody>
            </Card>

            <Card bg={cardBg}>
              <CardBody>
                <Stat>
                  <StatLabel>Completed</StatLabel>
                  <StatNumber color="green.500">{cityStatus.completed_agents}</StatNumber>
                  <StatHelpText>agents finished</StatHelpText>
                </Stat>
              </CardBody>
            </Card>
          </Grid>
        )}

        {/* Deploy City Section */}
        {(!cityStatus || cityStatus.status === 'initialized') && (
          <Card bg={cardBg} borderColor="teal.200" borderWidth="2px">
            <CardHeader>
              <Heading size="md">Deploy Agent City</Heading>
            </CardHeader>
            <CardBody>
              <VStack spacing={4} align="stretch">
                <Text>
                  Describe what you want to build, and Agent City will deploy 30 specialized agents 
                  across 9 districts to create your application.
                </Text>
                <textarea
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  placeholder="E.g., Build a modern e-commerce website with user authentication, product catalog, shopping cart, and payment integration..."
                  style={{
                    width: '100%',
                    minHeight: '100px',
                    padding: '12px',
                    border: '1px solid #E2E8F0',
                    borderRadius: '8px',
                    fontSize: '14px'
                  }}
                />
                <Button
                  leftIcon={<FiPlay />}
                  colorScheme="teal"
                  size="lg"
                  onClick={handleDeployCity}
                  isLoading={isDeploying}
                  loadingText="Deploying City..."
                  isDisabled={!requirements.trim()}
                >
                  Deploy Agent City
                </Button>
              </VStack>
            </CardBody>
          </Card>
        )}

        {/* Districts Grid */}
        {cityStatus && cityStatus.status !== 'initialized' && (
          <Card bg={cardBg}>
            <CardHeader>
              <Flex justify="space-between" align="center">
                <Heading size="md">Districts Overview</Heading>
                {cityStatus.current_wave < 9 && (
                  <Button
                    leftIcon={<FiActivity />}
                    colorScheme="blue"
                    size="sm"
                    onClick={handleAdvanceWave}
                  >
                    Advance Wave
                  </Button>
                )}
              </Flex>
            </CardHeader>
            <CardBody>
              <Grid templateColumns="repeat(auto-fit, minmax(250px, 1fr))" gap={4}>
                {Object.entries(cityStatus.districts).map(([districtName, district]: [string, any]) => (
                  <Card
                    key={districtName}
                    borderColor={borderColor}
                    borderWidth="1px"
                    cursor="pointer"
                    onClick={() => fetchDistrictDetails(districtName)}
                    _hover={{ borderColor: `${getDistrictColor(districtName)}.300`, shadow: 'md' }}
                    transition="all 0.2s"
                  >
                    <CardBody>
                      <VStack align="start" spacing={3}>
                        <Flex justify="space-between" align="center" w="100%">
                          <Text fontWeight="bold" textTransform="capitalize">
                            {districtName}
                          </Text>
                          <Badge colorScheme={getDistrictColor(districtName)}>
                            Wave {district.wave}
                          </Badge>
                        </Flex>
                        
                        <HStack spacing={4} w="100%">
                          <VStack align="start" spacing={1}>
                            <Text fontSize="sm" color="gray.600">Active</Text>
                            <Text fontWeight="bold" color="blue.500">
                              {district.agents_active}
                            </Text>
                          </VStack>
                          <VStack align="start" spacing={1}>
                            <Text fontSize="sm" color="gray.600">Complete</Text>
                            <Text fontWeight="bold" color="green.500">
                              {district.agents_completed}
                            </Text>
                          </VStack>
                          <VStack align="start" spacing={1}>
                            <Text fontSize="sm" color="gray.600">Total</Text>
                            <Text fontWeight="bold">
                              {district.agents_total}
                            </Text>
                          </VStack>
                        </HStack>

                        <Progress
                          value={(district.agents_completed / district.agents_total) * 100}
                          colorScheme={getDistrictColor(districtName)}
                          size="sm"
                          w="100%"
                        />

                        <Badge
                          colorScheme={district.is_complete ? 'green' : district.status === 'active' ? 'blue' : 'gray'}
                          size="sm"
                        >
                          {district.is_complete ? 'Complete' : district.status}
                        </Badge>
                      </VStack>
                    </CardBody>
                  </Card>
                ))}
              </Grid>
            </CardBody>
          </Card>
        )}

        {/* Live Logs */}
        {logs.length > 0 && (
          <Card bg={cardBg}>
            <CardHeader>
              <Heading size="md">Live Activity Logs</Heading>
            </CardHeader>
            <CardBody>
              <VStack align="stretch" spacing={2} maxH="300px" overflowY="auto">
                {logs.slice().reverse().map((log, index) => (
                  <Box
                    key={index}
                    p={3}
                    bg={useColorModeValue('gray.50', 'gray.700')}
                    borderRadius="md"
                    fontSize="sm"
                  >
                    <Flex justify="space-between" align="start">
                      <VStack align="start" spacing={1}>
                        <Text fontWeight="bold" color="teal.500">
                          {log.event_type.replace('_', ' ').toUpperCase()}
                        </Text>
                        <Text color="gray.600">
                          {JSON.stringify(log.data, null, 2)}
                        </Text>
                      </VStack>
                      <Text fontSize="xs" color="gray.500">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </Text>
                    </Flex>
                  </Box>
                ))}
              </VStack>
            </CardBody>
          </Card>
        )}
      </VStack>

      {/* District Details Modal */}
      <Modal isOpen={isDistrictOpen} onClose={onDistrictClose} size="xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            {selectedDistrict?.name.toUpperCase()} District
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {isLoading ? (
              <Flex justify="center" p={8}>
                <Spinner size="lg" />
              </Flex>
            ) : selectedDistrict ? (
              <VStack align="stretch" spacing={4}>
                <HStack spacing={4}>
                  <Badge colorScheme={getDistrictColor(selectedDistrict.name)}>
                    Wave {selectedDistrict.wave}
                  </Badge>
                  <Badge colorScheme={selectedDistrict.is_complete ? 'green' : 'blue'}>
                    {selectedDistrict.status}
                  </Badge>
                </HStack>

                <Text fontWeight="bold">Agents in this District:</Text>
                
                <Grid templateColumns="repeat(auto-fit, minmax(200px, 1fr))" gap={3}>
                  {selectedDistrict.agents.map((agent: Agent) => (
                    <Card
                      key={agent.id}
                      borderWidth="1px"
                      cursor="pointer"
                      onClick={() => fetchAgentDetails(agent.id)}
                      _hover={{ borderColor: 'teal.300', shadow: 'md' }}
                    >
                      <CardBody p={3}>
                        <VStack align="start" spacing={2}>
                          <Text fontWeight="bold" fontSize="sm">
                            {agent.name}
                          </Text>
                          <Badge colorScheme={getStatusColor(agent.status)} size="sm">
                            {agent.status}
                          </Badge>
                          <Text fontSize="xs" color="gray.600">
                            {agent.role}
                          </Text>
                        </VStack>
                      </CardBody>
                    </Card>
                  ))}
                </Grid>
              </VStack>
            ) : null}
          </ModalBody>
          <ModalFooter>
            <Button onClick={onDistrictClose}>Close</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      {/* Agent Details Modal */}
      <Modal isOpen={isAgentOpen} onClose={onAgentClose} size="lg">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            Agent Details
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {isLoading ? (
              <Flex justify="center" p={8}>
                <Spinner size="lg" />
              </Flex>
            ) : selectedAgent ? (
              <VStack align="stretch" spacing={4}>
                <HStack spacing={4}>
                  <Text fontWeight="bold" fontSize="lg">
                    {selectedAgent.name}
                  </Text>
                  <Badge colorScheme={getStatusColor(selectedAgent.status)}>
                    {selectedAgent.status}
                  </Badge>
                </HStack>

                <Box>
                  <Text fontWeight="bold" mb={2}>Role:</Text>
                  <Text>{selectedAgent.role}</Text>
                </Box>

                <Box>
                  <Text fontWeight="bold" mb={2}>Experience Level:</Text>
                  <Badge>{selectedAgent.experience_level}</Badge>
                </Box>

                <Box>
                  <Text fontWeight="bold" mb={2}>District:</Text>
                  <Badge colorScheme={getDistrictColor(selectedAgent.district)}>
                    {selectedAgent.district.toUpperCase()}
                  </Badge>
                </Box>

                {selectedAgent.current_task && (
                  <Box>
                    <Text fontWeight="bold" mb={2}>Current Task:</Text>
                    <Text fontSize="sm" color="gray.600">
                      {selectedAgent.current_task}
                    </Text>
                  </Box>
                )}

                {selectedAgent.dependencies.length > 0 && (
                  <Box>
                    <Text fontWeight="bold" mb={2}>Dependencies:</Text>
                    <HStack spacing={2} flexWrap="wrap">
                      {selectedAgent.dependencies.map((dep) => (
                        <Badge key={dep} variant="outline" size="sm">
                          {dep}
                        </Badge>
                      ))}
                    </HStack>
                  </Box>
                )}
              </VStack>
            ) : null}
          </ModalBody>
          <ModalFooter>
            <Button onClick={onAgentClose}>Close</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default AgentCity;

