import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Flex, 
  VStack, 
  HStack,
  Heading, 
  Text, 
  Button, 
  Badge,
  Card,
  CardBody,
  CardHeader,
  useColorModeValue,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Input,
  Select,
  Spinner
} from '@chakra-ui/react';
import { FiCreditCard, FiCheck, FiX, FiDollarSign, FiClock } from 'react-icons/fi';

interface PricingTier {
  name: string;
  price: number;
  hours: number;
  description: string;
}

interface UsageStats {
  user_id: string;
  tier: string;
  hours_used: number;
  hours_limit: number;
  hours_remaining: number;
  usage_percentage: number;
  is_active: boolean;
}

interface SubscriptionManagerProps {
  userId: string;
  onSubscriptionChange?: (tier: string) => void;
}

const SubscriptionManager: React.FC<SubscriptionManagerProps> = ({ 
  userId, 
  onSubscriptionChange 
}) => {
  const [pricing, setPricing] = useState<{ [key: string]: PricingTier }>({});
  const [usageStats, setUsageStats] = useState<UsageStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTier, setSelectedTier] = useState<string>('');
  const [email, setEmail] = useState('');
  const [checkoutUrl, setCheckoutUrl] = useState('');
  
  const { isOpen: isCheckoutOpen, onOpen: onCheckoutOpen, onClose: onCheckoutClose } = useDisclosure();
  const { isOpen: isUpgradeOpen, onOpen: onUpgradeOpen, onClose: onUpgradeClose } = useDisclosure();
  
  const cardBg = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  // Fetch pricing information
  const fetchPricing = async () => {
    try {
      const response = await fetch('/api/subscription/pricing');
      const data = await response.json();
      setPricing(data);
    } catch (error) {
      console.error('Failed to fetch pricing:', error);
    }
  };

  // Fetch usage statistics
  const fetchUsageStats = async () => {
    try {
      const response = await fetch(`/api/usage/stats/${userId}`);
      const data = await response.json();
      setUsageStats(data);
    } catch (error) {
      console.error('Failed to fetch usage stats:', error);
    }
  };

  // Create checkout session
  const createCheckoutSession = async () => {
    if (!email || !selectedTier) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/subscription/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          tier: selectedTier,
          success_url: `${window.location.origin}/subscription/success`,
          cancel_url: `${window.location.origin}/subscription/cancel`
        })
      });
      
      const data = await response.json();
      if (data.success) {
        setCheckoutUrl(data.checkout_url);
        // Redirect to Stripe Checkout
        window.location.href = data.checkout_url;
      } else {
        console.error('Failed to create checkout session:', data.error);
      }
    } catch (error) {
      console.error('Failed to create checkout session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle upgrade button click
  const handleUpgrade = (tier: string) => {
    setSelectedTier(tier);
    onUpgradeOpen();
  };

  // Get tier color
  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'free': return 'gray';
      case 'standard': return 'blue';
      case 'pro': return 'purple';
      default: return 'gray';
    }
  };

  // Get usage color based on percentage
  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return 'red';
    if (percentage >= 70) return 'yellow';
    return 'green';
  };

  useEffect(() => {
    fetchPricing();
    fetchUsageStats();
  }, [userId]);

  // Auto-refresh usage stats
  useEffect(() => {
    const interval = setInterval(fetchUsageStats, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [userId]);

  return (
    <Box p={6}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <VStack align="start" spacing={2}>
          <Heading size="lg" color="teal.500">
            <FiDollarSign style={{ display: 'inline', marginRight: '8px' }} />
            Subscription & Usage
          </Heading>
          <Text color="gray.600">
            Manage your subscription and track your development hours
          </Text>
        </VStack>

        {/* Current Usage Stats */}
        {usageStats && (
          <Card bg={cardBg} borderColor={borderColor} borderWidth="1px">
            <CardHeader>
              <Heading size="md">Current Usage</Heading>
            </CardHeader>
            <CardBody>
              <VStack spacing={4} align="stretch">
                <HStack justify="space-between">
                  <VStack align="start" spacing={1}>
                    <Text fontSize="sm" color="gray.600">Current Plan</Text>
                    <Badge colorScheme={getTierColor(usageStats.tier)} size="lg">
                      {usageStats.tier.toUpperCase()}
                    </Badge>
                  </VStack>
                  
                  <VStack align="end" spacing={1}>
                    <Text fontSize="sm" color="gray.600">Hours Used</Text>
                    <Text fontSize="lg" fontWeight="bold">
                      {usageStats.hours_used.toFixed(1)} / {usageStats.hours_limit}
                    </Text>
                  </VStack>
                </HStack>

                <Box>
                  <Flex justify="space-between" mb={2}>
                    <Text fontSize="sm">Usage Progress</Text>
                    <Text fontSize="sm" color={`${getUsageColor(usageStats.usage_percentage)}.500`}>
                      {usageStats.usage_percentage.toFixed(1)}%
                    </Text>
                  </Flex>
                  <Box
                    w="100%"
                    h="8px"
                    bg="gray.200"
                    borderRadius="full"
                    overflow="hidden"
                  >
                    <Box
                      h="100%"
                      bg={`${getUsageColor(usageStats.usage_percentage)}.400`}
                      w={`${Math.min(usageStats.usage_percentage, 100)}%`}
                      transition="width 0.3s ease"
                    />
                  </Box>
                </Box>

                <HStack justify="space-between">
                  <VStack align="start" spacing={1}>
                    <Text fontSize="sm" color="gray.600">Hours Remaining</Text>
                    <Text fontSize="lg" fontWeight="bold" color="green.500">
                      {usageStats.hours_remaining.toFixed(1)}
                    </Text>
                  </VStack>
                  
                  <VStack align="end" spacing={1}>
                    <Text fontSize="sm" color="gray.600">Status</Text>
                    <Badge colorScheme={usageStats.is_active ? 'green' : 'red'}>
                      {usageStats.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </VStack>
                </HStack>

                {usageStats.hours_remaining <= 0 && (
                  <Alert status="warning">
                    <AlertIcon />
                    <Box>
                      <AlertTitle>Usage Limit Reached!</AlertTitle>
                      <AlertDescription>
                        You've used all your development hours for this billing period. 
                        Upgrade your plan to continue building.
                      </AlertDescription>
                    </Box>
                  </Alert>
                )}
              </VStack>
            </CardBody>
          </Card>
        )}

        {/* Pricing Plans */}
        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px">
          <CardHeader>
            <Heading size="md">Pricing Plans</Heading>
          </CardHeader>
          <CardBody>
            <VStack spacing={4} align="stretch">
              {Object.entries(pricing).map(([tier, plan]) => (
                <Card
                  key={tier}
                  borderWidth="2px"
                  borderColor={usageStats?.tier === tier ? 'teal.300' : borderColor}
                  bg={usageStats?.tier === tier ? 'teal.50' : cardBg}
                >
                  <CardBody>
                    <Flex justify="space-between" align="center">
                      <VStack align="start" spacing={2}>
                        <HStack>
                          <Text fontSize="lg" fontWeight="bold">
                            {plan.name}
                          </Text>
                          {usageStats?.tier === tier && (
                            <Badge colorScheme="teal">Current Plan</Badge>
                          )}
                        </HStack>
                        
                        <Text color="gray.600" fontSize="sm">
                          {plan.description}
                        </Text>
                        
                        <HStack spacing={4}>
                          <HStack>
                            <FiDollarSign />
                            <Text fontWeight="bold">
                              ${plan.price}/month
                            </Text>
                          </HStack>
                          <HStack>
                            <FiClock />
                            <Text>
                              {plan.hours} hours
                            </Text>
                          </HStack>
                        </HStack>
                      </VStack>

                      <VStack spacing={2}>
                        {tier === 'free' ? (
                          <Badge colorScheme="gray" size="lg">
                            Free Trial
                          </Badge>
                        ) : usageStats?.tier === tier ? (
                          <Badge colorScheme="green" size="lg">
                            <FiCheck style={{ marginRight: '4px' }} />
                            Active
                          </Badge>
                        ) : (
                          <Button
                            colorScheme="teal"
                            size="sm"
                            onClick={() => handleUpgrade(tier)}
                            leftIcon={<FiCreditCard />}
                          >
                            Upgrade
                          </Button>
                        )}
                      </VStack>
                    </Flex>
                  </CardBody>
                </Card>
              ))}
            </VStack>
          </CardBody>
        </Card>

        {/* Usage Tips */}
        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px">
          <CardHeader>
            <Heading size="md">Usage Tips</Heading>
          </CardHeader>
          <CardBody>
            <VStack align="start" spacing={3}>
              <Text fontSize="sm">
                • <strong>Agent City</strong> uses development hours when actively building your projects
              </Text>
              <Text fontSize="sm">
                • Hours are tracked from when you deploy Agent City until project completion
              </Text>
              <Text fontSize="sm">
                • Pausing or stopping a project will pause the hour counter
              </Text>
              <Text fontSize="sm">
                • Usage resets at the beginning of each billing cycle
              </Text>
              <Text fontSize="sm">
                • Upgrade anytime to get more hours and unlock advanced features
              </Text>
            </VStack>
          </CardBody>
        </Card>
      </VStack>

      {/* Upgrade Modal */}
      <Modal isOpen={isUpgradeOpen} onClose={onUpgradeClose} size="md">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            Upgrade to {selectedTier && pricing[selectedTier]?.name}
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {selectedTier && pricing[selectedTier] && (
              <VStack spacing={4} align="stretch">
                <Alert status="info">
                  <AlertIcon />
                  <Box>
                    <AlertTitle>Upgrade Your Plan</AlertTitle>
                    <AlertDescription>
                      Get {pricing[selectedTier].hours} hours of development time for 
                      ${pricing[selectedTier].price}/month
                    </AlertDescription>
                  </Box>
                </Alert>

                <Box>
                  <Text mb={2} fontWeight="bold">Email Address</Text>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                  />
                </Box>

                <VStack spacing={2} align="start">
                  <Text fontWeight="bold">What you'll get:</Text>
                  <Text fontSize="sm">• {pricing[selectedTier].hours} hours of development time per month</Text>
                  <Text fontSize="sm">• Access to all 30 specialized AI agents</Text>
                  <Text fontSize="sm">• Priority support</Text>
                  <Text fontSize="sm">• Advanced project features</Text>
                  {selectedTier === 'pro' && (
                    <>
                      <Text fontSize="sm">• Extended project history</Text>
                      <Text fontSize="sm">• Custom agent configurations</Text>
                      <Text fontSize="sm">• API access</Text>
                    </>
                  )}
                </VStack>
              </VStack>
            )}
          </ModalBody>
          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onUpgradeClose}>
              Cancel
            </Button>
            <Button
              colorScheme="teal"
              onClick={createCheckoutSession}
              isLoading={isLoading}
              loadingText="Creating Checkout..."
              isDisabled={!email}
              leftIcon={<FiCreditCard />}
            >
              Continue to Payment
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default SubscriptionManager;

