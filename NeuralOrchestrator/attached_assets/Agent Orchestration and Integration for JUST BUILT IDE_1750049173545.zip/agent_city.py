"""
Agent City Orchestration System
Based on the AGENTBRAIN.txt concept for creating a 30-agent development city
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import json
import asyncio
from datetime import datetime
import uuid

class AgentStatus(Enum):
    IDLE = "idle"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"

class DistrictType(Enum):
    PLANNING = "planning"
    FOUNDATION = "foundation"
    COMPONENT = "component"
    LOGIC = "logic"
    DESIGN = "design"
    ANIMATION = "animation"
    PERFORMANCE = "performance"
    QUALITY = "quality"
    DEPLOYMENT = "deployment"

@dataclass
class Agent:
    """Individual agent in the Agent City"""
    id: str
    name: str
    district: DistrictType
    role: str
    experience_level: str
    dependencies: List[str] = field(default_factory=list)
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[str] = None
    output: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "district": self.district.value,
            "role": self.role,
            "experience_level": self.experience_level,
            "dependencies": self.dependencies,
            "status": self.status.value,
            "current_task": self.current_task,
            "output": self.output,
            "created_at": self.created_at.isoformat()
        }

@dataclass
class District:
    """District containing multiple agents"""
    name: DistrictType
    agents: List[Agent] = field(default_factory=list)
    wave: int = 0
    status: str = "inactive"
    
    def get_active_agents(self) -> List[Agent]:
        return [agent for agent in self.agents if agent.status == AgentStatus.WORKING]
    
    def get_completed_agents(self) -> List[Agent]:
        return [agent for agent in self.agents if agent.status == AgentStatus.COMPLETED]
    
    def is_complete(self) -> bool:
        return all(agent.status == AgentStatus.COMPLETED for agent in self.agents)

class AgentCity:
    """Main orchestration system for the 30-agent development city"""
    
    def __init__(self):
        self.districts: Dict[DistrictType, District] = {}
        self.agents: Dict[str, Agent] = {}
        self.current_wave = 0
        self.project_id: str = str(uuid.uuid4())
        self.status = "initialized"
        self.logs: List[Dict[str, Any]] = []
        
        self._initialize_districts()
        self._create_agents()
    
    def _initialize_districts(self):
        """Initialize all 9 districts"""
        for district_type in DistrictType:
            self.districts[district_type] = District(name=district_type)
    
    def _create_agents(self):
        """Create all 30 specialized agents across 9 districts"""
        
        # Planning District (Wave 1)
        planning_agents = [
            Agent("master_architect", "Master Architect", DistrictType.PLANNING, 
                  "Overall system architecture and design", "Senior", []),
            Agent("project_planner", "Project Planner", DistrictType.PLANNING,
                  "Project timeline and resource planning", "Senior", []),
            Agent("requirements_analyst", "Requirements Analyst", DistrictType.PLANNING,
                  "Requirements gathering and analysis", "Mid-level", [])
        ]
        
        # Foundation District (Wave 2)
        foundation_agents = [
            Agent("foundation_builder", "Foundation Builder", DistrictType.FOUNDATION,
                  "Core project structure and scaffolding", "Senior", ["master_architect"]),
            Agent("dependency_manager", "Dependency Manager", DistrictType.FOUNDATION,
                  "Package and dependency management", "Mid-level", ["foundation_builder"]),
            Agent("config_specialist", "Configuration Specialist", DistrictType.FOUNDATION,
                  "Environment and configuration setup", "Mid-level", ["foundation_builder"])
        ]
        
        # Component District (Wave 3)
        component_agents = [
            Agent("component_architect", "Component Architect", DistrictType.COMPONENT,
                  "Component structure and organization", "Senior", ["foundation_builder"]),
            Agent("button_specialist", "Button Specialist", DistrictType.COMPONENT,
                  "Button components and interactions", "Specialist", ["component_architect"]),
            Agent("form_builder", "Form Builder", DistrictType.COMPONENT,
                  "Form components and validation", "Specialist", ["component_architect"]),
            Agent("layout_designer", "Layout Designer", DistrictType.COMPONENT,
                  "Layout components and grid systems", "Mid-level", ["component_architect"])
        ]
        
        # Logic District (Wave 4)
        logic_agents = [
            Agent("state_manager", "State Manager", DistrictType.LOGIC,
                  "Application state management", "Senior", ["component_architect"]),
            Agent("hook_creator", "Hook Creator", DistrictType.LOGIC,
                  "Custom hooks and logic patterns", "Mid-level", ["state_manager"]),
            Agent("api_integrator", "API Integrator", DistrictType.LOGIC,
                  "API integration and data fetching", "Senior", ["state_manager"]),
            Agent("business_logic_engineer", "Business Logic Engineer", DistrictType.LOGIC,
                  "Core business logic implementation", "Senior", ["state_manager"])
        ]
        
        # Design District (Wave 5)
        design_agents = [
            Agent("ui_designer", "UI Designer", DistrictType.DESIGN,
                  "User interface design and styling", "Senior", ["layout_designer"]),
            Agent("theme_creator", "Theme Creator", DistrictType.DESIGN,
                  "Theme system and design tokens", "Mid-level", ["ui_designer"]),
            Agent("responsive_specialist", "Responsive Specialist", DistrictType.DESIGN,
                  "Responsive design and mobile optimization", "Specialist", ["ui_designer"]),
            Agent("icon_curator", "Icon Curator", DistrictType.DESIGN,
                  "Icon selection and management", "Junior", ["ui_designer"])
        ]
        
        # Animation District (Wave 6)
        animation_agents = [
            Agent("motion_designer", "Motion Designer", DistrictType.ANIMATION,
                  "Animation design and choreography", "Senior", ["ui_designer"]),
            Agent("microinteraction_specialist", "Micro-interaction Specialist", DistrictType.ANIMATION,
                  "Small interaction animations", "Specialist", ["motion_designer"]),
            Agent("transition_engineer", "Transition Engineer", DistrictType.ANIMATION,
                  "Page and component transitions", "Mid-level", ["motion_designer"])
        ]
        
        # Performance District (Wave 7)
        performance_agents = [
            Agent("performance_optimizer", "Performance Optimizer", DistrictType.PERFORMANCE,
                  "Performance analysis and optimization", "Senior", ["business_logic_engineer"]),
            Agent("cache_manager", "Cache Manager", DistrictType.PERFORMANCE,
                  "Caching strategies and implementation", "Mid-level", ["performance_optimizer"]),
            Agent("bundle_analyzer", "Bundle Analyzer", DistrictType.PERFORMANCE,
                  "Bundle size analysis and optimization", "Specialist", ["performance_optimizer"])
        ]
        
        # Quality District (Wave 8)
        quality_agents = [
            Agent("qa_lead", "QA Lead", DistrictType.QUALITY,
                  "Quality assurance and testing strategy", "Senior", ["performance_optimizer"]),
            Agent("unit_test_specialist", "Unit Test Specialist", DistrictType.QUALITY,
                  "Unit testing implementation", "Mid-level", ["qa_lead"]),
            Agent("integration_tester", "Integration Tester", DistrictType.QUALITY,
                  "Integration and E2E testing", "Mid-level", ["qa_lead"])
        ]
        
        # Deployment District (Wave 9)
        deployment_agents = [
            Agent("project_finalizer", "Project Finalizer", DistrictType.DEPLOYMENT,
                  "Final project assembly and preparation", "Senior", ["qa_lead"]),
            Agent("debug_specialist", "Debug Specialist", DistrictType.DEPLOYMENT,
                  "Final debugging and issue resolution", "Senior", ["project_finalizer"]),
            Agent("deployment_engineer", "Deployment Engineer", DistrictType.DEPLOYMENT,
                  "Deployment and production setup", "Senior", ["project_finalizer"])
        ]
        
        # Add all agents to their districts and the main registry
        all_agents = (planning_agents + foundation_agents + component_agents + 
                     logic_agents + design_agents + animation_agents + 
                     performance_agents + quality_agents + deployment_agents)
        
        for agent in all_agents:
            self.agents[agent.id] = agent
            self.districts[agent.district].agents.append(agent)
        
        # Set wave numbers for districts
        wave_mapping = {
            DistrictType.PLANNING: 1,
            DistrictType.FOUNDATION: 2,
            DistrictType.COMPONENT: 3,
            DistrictType.LOGIC: 4,
            DistrictType.DESIGN: 5,
            DistrictType.ANIMATION: 6,
            DistrictType.PERFORMANCE: 7,
            DistrictType.QUALITY: 8,
            DistrictType.DEPLOYMENT: 9
        }
        
        for district_type, wave in wave_mapping.items():
            self.districts[district_type].wave = wave
    
    def get_city_status(self) -> Dict[str, Any]:
        """Get overall city status"""
        total_agents = len(self.agents)
        active_agents = len([a for a in self.agents.values() if a.status == AgentStatus.WORKING])
        completed_agents = len([a for a in self.agents.values() if a.status == AgentStatus.COMPLETED])
        
        district_status = {}
        for district_type, district in self.districts.items():
            district_status[district_type.value] = {
                "wave": district.wave,
                "status": district.status,
                "agents_total": len(district.agents),
                "agents_active": len(district.get_active_agents()),
                "agents_completed": len(district.get_completed_agents()),
                "is_complete": district.is_complete()
            }
        
        return {
            "project_id": self.project_id,
            "status": self.status,
            "current_wave": self.current_wave,
            "total_agents": total_agents,
            "active_agents": active_agents,
            "completed_agents": completed_agents,
            "progress_percentage": (completed_agents / total_agents) * 100,
            "districts": district_status,
            "logs_count": len(self.logs)
        }
    
    def get_district_details(self, district_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific district"""
        try:
            district_type = DistrictType(district_name)
            district = self.districts[district_type]
            
            return {
                "name": district_name,
                "wave": district.wave,
                "status": district.status,
                "agents": [agent.to_dict() for agent in district.agents],
                "is_complete": district.is_complete()
            }
        except ValueError:
            return {"error": f"District '{district_name}' not found"}
    
    def get_agent_details(self, agent_id: str) -> Dict[str, Any]:
        """Get detailed information about a specific agent"""
        if agent_id in self.agents:
            return self.agents[agent_id].to_dict()
        return {"error": f"Agent '{agent_id}' not found"}
    
    def deploy_city(self, project_requirements: str) -> Dict[str, Any]:
        """Deploy the Agent City to start working on a project"""
        self.status = "deploying"
        self.current_wave = 1
        
        # Log the deployment
        self._log_event("city_deployed", {
            "project_requirements": project_requirements,
            "total_agents": len(self.agents),
            "total_districts": len(self.districts)
        })
        
        # Activate the first wave (Planning District)
        planning_district = self.districts[DistrictType.PLANNING]
        planning_district.status = "active"
        
        for agent in planning_district.agents:
            agent.status = AgentStatus.WORKING
            agent.current_task = f"Analyzing requirements: {project_requirements[:100]}..."
        
        self.status = "active"
        
        return {
            "success": True,
            "message": "Agent City deployed successfully",
            "project_id": self.project_id,
            "active_wave": self.current_wave,
            "active_district": "planning"
        }
    
    def advance_wave(self) -> Dict[str, Any]:
        """Advance to the next wave of agents"""
        if self.current_wave >= 9:
            return {"success": False, "message": "All waves completed"}
        
        # Check if current wave is complete
        current_districts = [d for d in self.districts.values() if d.wave == self.current_wave]
        if not all(d.is_complete() for d in current_districts):
            return {"success": False, "message": "Current wave not yet complete"}
        
        self.current_wave += 1
        
        # Activate next wave districts
        next_districts = [d for d in self.districts.values() if d.wave == self.current_wave]
        
        for district in next_districts:
            district.status = "active"
            for agent in district.agents:
                # Check if dependencies are met
                dependencies_met = all(
                    self.agents[dep_id].status == AgentStatus.COMPLETED 
                    for dep_id in agent.dependencies 
                    if dep_id in self.agents
                )
                
                if dependencies_met:
                    agent.status = AgentStatus.WORKING
                    agent.current_task = f"Working on wave {self.current_wave} tasks"
                else:
                    agent.status = AgentStatus.WAITING
        
        self._log_event("wave_advanced", {
            "new_wave": self.current_wave,
            "active_districts": [d.name.value for d in next_districts]
        })
        
        return {
            "success": True,
            "message": f"Advanced to wave {self.current_wave}",
            "active_wave": self.current_wave,
            "active_districts": [d.name.value for d in next_districts]
        }
    
    def complete_agent_task(self, agent_id: str, output: Dict[str, Any]) -> Dict[str, Any]:
        """Mark an agent's task as complete"""
        if agent_id not in self.agents:
            return {"success": False, "message": f"Agent '{agent_id}' not found"}
        
        agent = self.agents[agent_id]
        agent.status = AgentStatus.COMPLETED
        agent.output = output
        agent.current_task = None
        
        self._log_event("agent_completed", {
            "agent_id": agent_id,
            "agent_name": agent.name,
            "district": agent.district.value,
            "output_keys": list(output.keys()) if output else []
        })
        
        # Check if any waiting agents can now start
        self._check_waiting_agents()
        
        return {
            "success": True,
            "message": f"Agent '{agent.name}' task completed",
            "agent_status": agent.status.value
        }
    
    def _check_waiting_agents(self):
        """Check if any waiting agents can now start working"""
        waiting_agents = [a for a in self.agents.values() if a.status == AgentStatus.WAITING]
        
        for agent in waiting_agents:
            dependencies_met = all(
                self.agents[dep_id].status == AgentStatus.COMPLETED 
                for dep_id in agent.dependencies 
                if dep_id in self.agents
            )
            
            if dependencies_met:
                agent.status = AgentStatus.WORKING
                agent.current_task = f"Dependencies met, starting work"
                
                self._log_event("agent_activated", {
                    "agent_id": agent.id,
                    "agent_name": agent.name,
                    "district": agent.district.value
                })
    
    def _log_event(self, event_type: str, data: Dict[str, Any]):
        """Log an event in the city"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "data": data
        }
        self.logs.append(log_entry)
    
    def get_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent logs"""
        return self.logs[-limit:]
    
    def reset_city(self):
        """Reset the city to initial state"""
        self.current_wave = 0
        self.status = "initialized"
        self.logs = []
        
        for agent in self.agents.values():
            agent.status = AgentStatus.IDLE
            agent.current_task = None
            agent.output = None
        
        for district in self.districts.values():
            district.status = "inactive"

