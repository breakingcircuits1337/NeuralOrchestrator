import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import json
from datetime import datetime
import uuid

# Import our new modules
from agent_city import AgentCity, DistrictType, AgentStatus
from stripe_integration import StripeManager, UsageTracker, SubscriptionTier

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize Agent City and Stripe integration
agent_city = AgentCity()
usage_tracker = UsageTracker()

# Initialize Stripe (in production, these would come from environment variables)
STRIPE_SECRET_KEY = os.getenv('STRIPE_SECRET_KEY', 'sk_test_...')  # Replace with actual key
STRIPE_WEBHOOK_SECRET = os.getenv('STRIPE_WEBHOOK_SECRET', 'whsec_...')  # Replace with actual secret
stripe_manager = StripeManager(STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET)

# Routes for LLM operations
@app.route('/api/llm/models', methods=['GET'])
def get_available_models():
    """Return a list of available LLM models"""
    models = [
        {"id": "gemini", "name": "Google Gemini", "available": True},
        {"id": "mistral", "name": "Mistral AI", "available": True},
        {"id": "groq", "name": "Groq", "available": True},
        {"id": "ollama", "name": "Ollama (Local)", "available": True, "endpoint": "127.0.0.1:9632"}
    ]
    return jsonify(models)

@app.route('/api/llm/generate-plan', methods=['POST'])
def generate_plan():
    """Generate a development plan based on user input"""
    data = request.json
    user_input = data.get('input', '')
    selected_model = data.get('model', 'gemini')
    user_id = data.get('user_id', 'anonymous')
    
    # Check user's subscription and usage
    usage_stats = usage_tracker.get_usage_stats(user_id)
    if usage_stats['hours_remaining'] <= 0:
        return jsonify({
            "error": "Usage limit exceeded",
            "message": "Please upgrade your subscription to continue",
            "usage_stats": usage_stats
        }), 403
    
    # Deploy Agent City for this project
    deployment_result = agent_city.deploy_city(user_input)
    
    if not deployment_result['success']:
        return jsonify({"error": "Failed to deploy Agent City"}), 500
    
    # Mock response for now - will be replaced with actual LLM calls
    mock_plan = [
        {"id": 1, "title": "Setup project structure", "description": "Create basic folder structure and initialize project files", "estimated_time": "5 minutes"},
        {"id": 2, "title": "Create HTML layout", "description": "Implement the basic HTML structure for the application", "estimated_time": "10 minutes"},
        {"id": 3, "title": "Add CSS styling", "description": "Style the application with CSS to match design requirements", "estimated_time": "15 minutes"},
        {"id": 4, "title": "Implement core functionality", "description": "Add JavaScript code for the main application features", "estimated_time": "30 minutes"},
        {"id": 5, "title": "Test and debug", "description": "Test the application and fix any issues", "estimated_time": "20 minutes"}
    ]
    
    return jsonify({
        "plan": mock_plan,
        "model_used": selected_model,
        "input": user_input,
        "agent_city": {
            "project_id": deployment_result['project_id'],
            "status": "deployed",
            "active_wave": deployment_result['active_wave']
        },
        "usage_stats": usage_stats
    })

@app.route('/api/llm/execute-step', methods=['POST'])
def execute_step():
    """Execute a specific step in the development plan"""
    data = request.json
    step_id = data.get('step_id')
    plan_id = data.get('plan_id')
    user_id = data.get('user_id', 'anonymous')
    
    # Check usage limits
    usage_stats = usage_tracker.get_usage_stats(user_id)
    if usage_stats['hours_remaining'] <= 0:
        return jsonify({
            "error": "Usage limit exceeded",
            "message": "Please upgrade your subscription to continue"
        }), 403
    
    # Mock response - will be replaced with actual LLM code generation
    mock_code = """
    function setupApplication() {
      const app = document.getElementById('app');
      app.innerHTML = '<h1>Hello World</h1>';
      console.log('Application initialized');
      return app;
    }
    
    // Initialize the application
    document.addEventListener('DOMContentLoaded', () => {
      setupApplication();
    });
    """
    
    return jsonify({
        "success": True,
        "step_id": step_id,
        "code": mock_code,
        "message": f"Step {step_id} executed successfully",
        "usage_stats": usage_stats
    })

# Agent City API Routes
@app.route('/api/agent-city/status', methods=['GET'])
def get_agent_city_status():
    """Get overall Agent City status"""
    return jsonify(agent_city.get_city_status())

@app.route('/api/agent-city/district/<district_name>', methods=['GET'])
def get_district_details(district_name):
    """Get detailed information about a specific district"""
    return jsonify(agent_city.get_district_details(district_name))

@app.route('/api/agent-city/agent/<agent_id>', methods=['GET'])
def get_agent_details(agent_id):
    """Get detailed information about a specific agent"""
    return jsonify(agent_city.get_agent_details(agent_id))

@app.route('/api/agent-city/deploy', methods=['POST'])
def deploy_agent_city():
    """Deploy Agent City for a new project"""
    data = request.json
    requirements = data.get('requirements', '')
    user_id = data.get('user_id', 'anonymous')
    
    # Check usage limits
    usage_stats = usage_tracker.get_usage_stats(user_id)
    if usage_stats['hours_remaining'] <= 0:
        return jsonify({
            "error": "Usage limit exceeded",
            "message": "Please upgrade your subscription to continue"
        }), 403
    
    # Start a new session
    session_result = usage_tracker.start_session(user_id)
    if not session_result['success']:
        return jsonify(session_result), 403
    
    result = agent_city.deploy_city(requirements)
    result['session_id'] = session_result['session_id']
    result['usage_stats'] = usage_tracker.get_usage_stats(user_id)
    
    return jsonify(result)

@app.route('/api/agent-city/advance-wave', methods=['POST'])
def advance_wave():
    """Advance to the next wave of agents"""
    return jsonify(agent_city.advance_wave())

@app.route('/api/agent-city/complete-agent', methods=['POST'])
def complete_agent_task():
    """Mark an agent's task as complete"""
    data = request.json
    agent_id = data.get('agent_id')
    output = data.get('output', {})
    
    return jsonify(agent_city.complete_agent_task(agent_id, output))

@app.route('/api/agent-city/logs', methods=['GET'])
def get_agent_city_logs():
    """Get Agent City logs"""
    limit = request.args.get('limit', 50, type=int)
    return jsonify(agent_city.get_logs(limit))

@app.route('/api/agent-city/reset', methods=['POST'])
def reset_agent_city():
    """Reset Agent City to initial state"""
    agent_city.reset_city()
    return jsonify({"success": True, "message": "Agent City reset successfully"})

# Subscription and Usage API Routes
@app.route('/api/subscription/pricing', methods=['GET'])
def get_pricing():
    """Get pricing information"""
    pricing = {
        "free": {
            "name": "Free Trial",
            "price": 0,
            "hours": 1,
            "description": "Try Just Built IDE with 1 hour of development time"
        },
        "standard": {
            "name": "Standard",
            "price": 20,
            "hours": 6,
            "description": "Perfect for small projects and learning"
        },
        "pro": {
            "name": "Pro",
            "price": 40,
            "hours": 15,
            "description": "Ideal for serious developers and larger projects"
        }
    }
    return jsonify(pricing)

@app.route('/api/subscription/create-checkout', methods=['POST'])
def create_checkout_session():
    """Create a Stripe checkout session"""
    data = request.json
    user_email = data.get('email')
    tier = data.get('tier')
    success_url = data.get('success_url')
    cancel_url = data.get('cancel_url')
    
    if not all([user_email, tier, success_url, cancel_url]):
        return jsonify({"error": "Missing required fields"}), 400
    
    try:
        subscription_tier = SubscriptionTier(tier)
    except ValueError:
        return jsonify({"error": "Invalid subscription tier"}), 400
    
    # Create or get customer
    customer_result = stripe_manager.create_customer(user_email)
    if not customer_result['success']:
        return jsonify(customer_result), 400
    
    # Create checkout session
    checkout_result = stripe_manager.create_checkout_session(
        customer_result['customer_id'],
        subscription_tier,
        success_url,
        cancel_url
    )
    
    return jsonify(checkout_result)

@app.route('/api/subscription/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhooks"""
    payload = request.get_data(as_text=True)
    signature = request.headers.get('Stripe-Signature')
    
    result = stripe_manager.handle_webhook(payload, signature)
    
    # Update user subscription based on webhook event
    if result['success'] and 'customer_id' in result:
        # Here you would update the user's subscription in your database
        # For now, we'll just log it
        print(f"Webhook processed: {result}")
    
    return jsonify(result)

@app.route('/api/usage/stats/<user_id>', methods=['GET'])
def get_usage_stats(user_id):
    """Get usage statistics for a user"""
    return jsonify(usage_tracker.get_usage_stats(user_id))

@app.route('/api/usage/start-session', methods=['POST'])
def start_session():
    """Start a new development session"""
    data = request.json
    user_id = data.get('user_id', 'anonymous')
    
    return jsonify(usage_tracker.start_session(user_id))

@app.route('/api/usage/end-session', methods=['POST'])
def end_session():
    """End a development session"""
    data = request.json
    session_id = data.get('session_id')
    
    if not session_id:
        return jsonify({"error": "Session ID required"}), 400
    
    return jsonify(usage_tracker.end_session(session_id))

# Routes for file management
@app.route('/api/files/list', methods=['GET'])
def list_files():
    """List all files in the project"""
    # Mock response - will be replaced with actual file system operations
    mock_files = [
        {"name": "index.html", "type": "file", "path": "/project/index.html", "size": 1024},
        {"name": "styles", "type": "directory", "path": "/project/styles", "children": [
            {"name": "main.css", "type": "file", "path": "/project/styles/main.css", "size": 512}
        ]},
        {"name": "scripts", "type": "directory", "path": "/project/scripts", "children": [
            {"name": "app.js", "type": "file", "path": "/project/scripts/app.js", "size": 2048}
        ]}
    ]
    return jsonify(mock_files)

@app.route('/api/files/save', methods=['POST'])
def save_file():
    """Save a file to the project"""
    # Will be implemented with actual file system operations
    return jsonify({"success": True, "message": "File saved successfully"})

# GitHub integration routes
@app.route('/api/github/repos', methods=['GET'])
def list_github_repos():
    """List GitHub repositories for the authenticated user"""
    # Will be implemented with GitHub API integration
    mock_repos = [
        {"name": "my-project", "url": "https://github.com/user/my-project", "stars": 5},
        {"name": "another-project", "url": "https://github.com/user/another-project", "stars": 10}
    ]
    return jsonify(mock_repos)

# Build and deployment routes
@app.route('/api/build/options', methods=['GET'])
def get_build_options():
    """Get available build options"""
    options = [
        {"id": "local", "name": "Local Build", "description": "Build for local use"},
        {"id": "web", "name": "Web Deployment", "description": "Build for web deployment"},
        {"id": "hybrid", "name": "Hybrid Build", "description": "Build for both local and web use"}
    ]
    return jsonify(options)

@app.route('/api/build/start', methods=['POST'])
def start_build():
    """Start a build process"""
    data = request.json
    build_type = data.get('type', 'web')
    
    return jsonify({
        "success": True,
        "build_id": "build-123",
        "message": f"Build process started for {build_type}"
    })

# Health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "agent_city_status": agent_city.status,
        "version": "1.0.0"
    })

# Serve static files from the React build directory in production
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    # Initialize Stripe products on startup (in production, this would be done once)
    print("Initializing Stripe products...")
    stripe_result = stripe_manager.create_stripe_products()
    if stripe_result['success']:
        print("Stripe products created successfully")
    else:
        print(f"Failed to create Stripe products: {stripe_result['error']}")
    
    print("Starting Just Built IDE Backend...")
    print(f"Agent City initialized with {len(agent_city.agents)} agents across {len(agent_city.districts)} districts")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

