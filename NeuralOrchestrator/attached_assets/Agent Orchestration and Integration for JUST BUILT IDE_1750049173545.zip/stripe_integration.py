"""
Stripe Integration for Just Built IDE
Handles subscription management and usage tracking
"""

import stripe
import os
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

class SubscriptionTier(Enum):
    FREE = "free"
    STANDARD = "standard"  # $20/month for 6 hours
    PRO = "pro"           # $40/month for 15 hours

@dataclass
class UserSubscription:
    user_id: str
    tier: SubscriptionTier
    stripe_customer_id: Optional[str]
    stripe_subscription_id: Optional[str]
    hours_used: float = 0.0
    hours_limit: float = 0.0
    billing_period_start: Optional[datetime] = None
    billing_period_end: Optional[datetime] = None
    is_active: bool = True

class StripeManager:
    """Manages Stripe integration for subscription billing"""
    
    def __init__(self, stripe_secret_key: str, webhook_secret: str):
        stripe.api_key = stripe_secret_key
        self.webhook_secret = webhook_secret
        
        # Pricing configuration
        self.pricing_config = {
            SubscriptionTier.FREE: {
                "price": 0,
                "hours": 1,  # 1 hour free trial
                "stripe_price_id": None
            },
            SubscriptionTier.STANDARD: {
                "price": 2000,  # $20.00 in cents
                "hours": 6,
                "stripe_price_id": None  # Will be set when creating products
            },
            SubscriptionTier.PRO: {
                "price": 4000,  # $40.00 in cents
                "hours": 15,
                "stripe_price_id": None  # Will be set when creating products
            }
        }
    
    def create_stripe_products(self) -> Dict[str, Any]:
        """Create Stripe products and prices for subscription tiers"""
        try:
            # Create Standard tier product
            standard_product = stripe.Product.create(
                name="Just Built IDE - Standard",
                description="6 hours of AI-powered development per month",
                metadata={"tier": "standard"}
            )
            
            standard_price = stripe.Price.create(
                product=standard_product.id,
                unit_amount=2000,  # $20.00
                currency="usd",
                recurring={"interval": "month"},
                metadata={"tier": "standard", "hours": "6"}
            )
            
            # Create Pro tier product
            pro_product = stripe.Product.create(
                name="Just Built IDE - Pro",
                description="15 hours of AI-powered development per month",
                metadata={"tier": "pro"}
            )
            
            pro_price = stripe.Price.create(
                product=pro_product.id,
                unit_amount=4000,  # $40.00
                currency="usd",
                recurring={"interval": "month"},
                metadata={"tier": "pro", "hours": "15"}
            )
            
            # Update pricing config with Stripe price IDs
            self.pricing_config[SubscriptionTier.STANDARD]["stripe_price_id"] = standard_price.id
            self.pricing_config[SubscriptionTier.PRO]["stripe_price_id"] = pro_price.id
            
            return {
                "success": True,
                "standard_price_id": standard_price.id,
                "pro_price_id": pro_price.id
            }
            
        except stripe.error.StripeError as e:
            return {"success": False, "error": str(e)}
    
    def create_customer(self, email: str, name: str = None) -> Dict[str, Any]:
        """Create a new Stripe customer"""
        try:
            customer = stripe.Customer.create(
                email=email,
                name=name,
                metadata={"source": "just_built_ide"}
            )
            
            return {
                "success": True,
                "customer_id": customer.id,
                "customer": customer
            }
            
        except stripe.error.StripeError as e:
            return {"success": False, "error": str(e)}
    
    def create_checkout_session(self, customer_id: str, tier: SubscriptionTier, 
                              success_url: str, cancel_url: str) -> Dict[str, Any]:
        """Create a Stripe checkout session for subscription"""
        if tier == SubscriptionTier.FREE:
            return {"success": False, "error": "Free tier doesn't require checkout"}
        
        price_id = self.pricing_config[tier]["stripe_price_id"]
        if not price_id:
            return {"success": False, "error": "Price ID not configured for this tier"}
        
        try:
            session = stripe.checkout.Session.create(
                customer=customer_id,
                payment_method_types=["card"],
                line_items=[{
                    "price": price_id,
                    "quantity": 1,
                }],
                mode="subscription",
                success_url=success_url,
                cancel_url=cancel_url,
                metadata={
                    "tier": tier.value,
                    "hours": str(self.pricing_config[tier]["hours"])
                }
            )
            
            return {
                "success": True,
                "checkout_url": session.url,
                "session_id": session.id
            }
            
        except stripe.error.StripeError as e:
            return {"success": False, "error": str(e)}
    
    def handle_webhook(self, payload: str, signature: str) -> Dict[str, Any]:
        """Handle Stripe webhook events"""
        try:
            event = stripe.Webhook.construct_event(
                payload, signature, self.webhook_secret
            )
            
            if event["type"] == "checkout.session.completed":
                return self._handle_checkout_completed(event["data"]["object"])
            elif event["type"] == "invoice.payment_succeeded":
                return self._handle_payment_succeeded(event["data"]["object"])
            elif event["type"] == "customer.subscription.deleted":
                return self._handle_subscription_cancelled(event["data"]["object"])
            
            return {"success": True, "message": "Event processed"}
            
        except ValueError as e:
            return {"success": False, "error": "Invalid payload"}
        except stripe.error.SignatureVerificationError as e:
            return {"success": False, "error": "Invalid signature"}
    
    def _handle_checkout_completed(self, session) -> Dict[str, Any]:
        """Handle successful checkout completion"""
        customer_id = session["customer"]
        subscription_id = session["subscription"]
        tier = session["metadata"]["tier"]
        
        # Here you would update your database with the new subscription
        return {
            "success": True,
            "event": "checkout_completed",
            "customer_id": customer_id,
            "subscription_id": subscription_id,
            "tier": tier
        }
    
    def _handle_payment_succeeded(self, invoice) -> Dict[str, Any]:
        """Handle successful payment"""
        customer_id = invoice["customer"]
        subscription_id = invoice["subscription"]
        
        # Reset usage for the new billing period
        return {
            "success": True,
            "event": "payment_succeeded",
            "customer_id": customer_id,
            "subscription_id": subscription_id,
            "action": "reset_usage"
        }
    
    def _handle_subscription_cancelled(self, subscription) -> Dict[str, Any]:
        """Handle subscription cancellation"""
        customer_id = subscription["customer"]
        subscription_id = subscription["id"]
        
        return {
            "success": True,
            "event": "subscription_cancelled",
            "customer_id": customer_id,
            "subscription_id": subscription_id,
            "action": "downgrade_to_free"
        }
    
    def get_subscription_info(self, subscription_id: str) -> Dict[str, Any]:
        """Get subscription information from Stripe"""
        try:
            subscription = stripe.Subscription.retrieve(subscription_id)
            
            return {
                "success": True,
                "subscription": {
                    "id": subscription.id,
                    "status": subscription.status,
                    "current_period_start": subscription.current_period_start,
                    "current_period_end": subscription.current_period_end,
                    "cancel_at_period_end": subscription.cancel_at_period_end
                }
            }
            
        except stripe.error.StripeError as e:
            return {"success": False, "error": str(e)}
    
    def cancel_subscription(self, subscription_id: str, at_period_end: bool = True) -> Dict[str, Any]:
        """Cancel a subscription"""
        try:
            if at_period_end:
                subscription = stripe.Subscription.modify(
                    subscription_id,
                    cancel_at_period_end=True
                )
            else:
                subscription = stripe.Subscription.delete(subscription_id)
            
            return {
                "success": True,
                "subscription_id": subscription_id,
                "cancelled_at_period_end": at_period_end
            }
            
        except stripe.error.StripeError as e:
            return {"success": False, "error": str(e)}

class UsageTracker:
    """Tracks usage hours for users"""
    
    def __init__(self):
        # In a real implementation, this would use a database
        self.user_sessions: Dict[str, Dict[str, Any]] = {}
        self.user_subscriptions: Dict[str, UserSubscription] = {}
    
    def start_session(self, user_id: str) -> Dict[str, Any]:
        """Start a new development session"""
        subscription = self.get_user_subscription(user_id)
        
        if not subscription.is_active:
            return {"success": False, "error": "Subscription not active"}
        
        if subscription.hours_used >= subscription.hours_limit:
            return {"success": False, "error": "Usage limit exceeded"}
        
        session_id = f"session_{user_id}_{datetime.now().timestamp()}"
        self.user_sessions[session_id] = {
            "user_id": user_id,
            "start_time": datetime.now(),
            "end_time": None,
            "duration_hours": 0.0
        }
        
        return {
            "success": True,
            "session_id": session_id,
            "remaining_hours": subscription.hours_limit - subscription.hours_used
        }
    
    def end_session(self, session_id: str) -> Dict[str, Any]:
        """End a development session and update usage"""
        if session_id not in self.user_sessions:
            return {"success": False, "error": "Session not found"}
        
        session = self.user_sessions[session_id]
        session["end_time"] = datetime.now()
        
        duration = session["end_time"] - session["start_time"]
        duration_hours = duration.total_seconds() / 3600
        session["duration_hours"] = duration_hours
        
        # Update user's total usage
        user_id = session["user_id"]
        subscription = self.get_user_subscription(user_id)
        subscription.hours_used += duration_hours
        
        return {
            "success": True,
            "session_duration_hours": duration_hours,
            "total_hours_used": subscription.hours_used,
            "remaining_hours": max(0, subscription.hours_limit - subscription.hours_used)
        }
    
    def get_user_subscription(self, user_id: str) -> UserSubscription:
        """Get or create user subscription"""
        if user_id not in self.user_subscriptions:
            # Create free tier subscription for new users
            self.user_subscriptions[user_id] = UserSubscription(
                user_id=user_id,
                tier=SubscriptionTier.FREE,
                stripe_customer_id=None,
                stripe_subscription_id=None,
                hours_used=0.0,
                hours_limit=1.0,  # 1 hour free
                billing_period_start=datetime.now(),
                billing_period_end=datetime.now() + timedelta(days=30),
                is_active=True
            )
        
        return self.user_subscriptions[user_id]
    
    def update_subscription(self, user_id: str, tier: SubscriptionTier, 
                          stripe_customer_id: str = None, 
                          stripe_subscription_id: str = None) -> Dict[str, Any]:
        """Update user's subscription tier"""
        subscription = self.get_user_subscription(user_id)
        
        subscription.tier = tier
        subscription.stripe_customer_id = stripe_customer_id
        subscription.stripe_subscription_id = stripe_subscription_id
        
        # Set hours limit based on tier
        if tier == SubscriptionTier.FREE:
            subscription.hours_limit = 1.0
        elif tier == SubscriptionTier.STANDARD:
            subscription.hours_limit = 6.0
        elif tier == SubscriptionTier.PRO:
            subscription.hours_limit = 15.0
        
        # Reset usage for new billing period
        subscription.hours_used = 0.0
        subscription.billing_period_start = datetime.now()
        subscription.billing_period_end = datetime.now() + timedelta(days=30)
        
        return {
            "success": True,
            "tier": tier.value,
            "hours_limit": subscription.hours_limit,
            "hours_used": subscription.hours_used
        }
    
    def get_usage_stats(self, user_id: str) -> Dict[str, Any]:
        """Get usage statistics for a user"""
        subscription = self.get_user_subscription(user_id)
        
        return {
            "user_id": user_id,
            "tier": subscription.tier.value,
            "hours_used": subscription.hours_used,
            "hours_limit": subscription.hours_limit,
            "hours_remaining": max(0, subscription.hours_limit - subscription.hours_used),
            "usage_percentage": (subscription.hours_used / subscription.hours_limit) * 100,
            "billing_period_start": subscription.billing_period_start.isoformat() if subscription.billing_period_start else None,
            "billing_period_end": subscription.billing_period_end.isoformat() if subscription.billing_period_end else None,
            "is_active": subscription.is_active
        }

